package com.flutura.datawrangler

import com.flutura.datawrangler.SessionRepl.{closeSession, executeCode,processLine, openSession,processModule}
import com.sun.javafx.scene.control.skin.Utils.getResource

import java.io.{File, PrintWriter}
import scala.io.Source
import scala.io.Source.fromFile


object test extends App{

  openSession("Session1")
 executeCode("Session1","import $file.test_script")
// executeCode("Session1","")
  processModule("Session1",os.pwd/"test_script.sc")
//  executeCode("Session1", "println(x)")
//  processLine("Session1","println(5)")
//  processModule("Session1",os.pwd/"src"/"main"/"scala"/"resources"/"test_script.sc")
// executeModule("Session1",os.pwd/"src"/"main"/"scala"/"resources"/"test_script.sc")
  closeSession("Session1")

//  openSession("Session2")
//  execute("Session2","val y = 6")
//  execute("Session2", "println(y+5)")
//  closeSession("Session2")
//  closeSession("Session1")

}
